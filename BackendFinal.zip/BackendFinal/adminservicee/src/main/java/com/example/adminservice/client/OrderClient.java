package com.example.adminservice.client;

import com.example.adminservice.dto.LeaderboardDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "orderservice", url = "http://localhost:8084")
public interface OrderClient {

    @GetMapping("/orders/rating/leaderboard")
    List<LeaderboardDTO> getLeaderboard();
}
