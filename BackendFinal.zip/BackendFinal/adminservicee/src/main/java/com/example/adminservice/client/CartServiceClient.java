package com.example.adminservice.client;

import com.example.adminservice.dto.WashPackageDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "cartservice", url = "http://localhost:8089") // use your actual CartService port
public interface CartServiceClient {

    @PostMapping("/wash-packages")
    WashPackageDTO add(@RequestBody WashPackageDTO dto);

    @PutMapping("/wash-packages/{id}")
    WashPackageDTO update(@PathVariable Long id, @RequestBody WashPackageDTO dto);

    @DeleteMapping("/wash-packages/{id}")
    void delete(@PathVariable Long id);

    @GetMapping("/wash-packages/{id}")
    WashPackageDTO getById(@PathVariable Long id);

    @GetMapping("/wash-packages")
    List<WashPackageDTO> getAll();
}
