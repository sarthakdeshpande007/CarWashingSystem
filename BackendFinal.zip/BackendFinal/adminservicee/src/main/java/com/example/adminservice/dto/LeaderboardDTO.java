package com.example.adminservice.dto;

public class LeaderboardDTO {
    private int rank;
    private String washerEmail;
    private double averageRating;

    public LeaderboardDTO() {}

    public LeaderboardDTO(int rank, String washerEmail, double averageRating) {
        this.rank = rank;
        this.washerEmail = washerEmail;
        this.averageRating = averageRating;
    }

    // Getters and Setters
    public int getRank() {
        return rank;
    }

    public void setRank(int rank) {
        this.rank = rank;
    }

    public String getWasherEmail() {
        return washerEmail;
    }

    public void setWasherEmail(String washerEmail) {
        this.washerEmail = washerEmail;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }
}
