// src/main/java/com/example/adminservice/controller/AdminRatingsController.java
package com.example.adminservice.controller;

import com.example.adminservice.client.OrderClient;
import com.example.adminservice.dto.LeaderboardDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/ratings")
public class AdminRatingsController {

    @Autowired
    private OrderClient orderClient;

    private static final String ADMIN_EMAIL = "admin@wash.com";

    private boolean isAuthorized(User user) {
        return user != null && ADMIN_EMAIL.equals(user.getUsername());
    }

    /** 🏆  GET  /admin/ratings/leaderboard */
    @GetMapping("/leaderboard")
    public ResponseEntity<?> getLeaderboard(@AuthenticationPrincipal User user) {
        if (!isAuthorized(user)) {
            return ResponseEntity.status(401).body("Unauthorized access");
        }
        List<LeaderboardDTO> board = orderClient.getLeaderboard();
        return ResponseEntity.ok(board);
    }
}
