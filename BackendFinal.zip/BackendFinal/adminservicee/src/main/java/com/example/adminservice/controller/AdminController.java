package com.example.adminservice.controller;

import com.example.adminservice.client.CartServiceClient;
import com.example.adminservice.dto.WashPackageDTO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/admin/wash-packages")
public class AdminController {

    @Autowired
    private CartServiceClient cartClient;

    private static final String ADMIN_EMAIL = "admin@wash.com";

    private boolean isAuthorized(User user) {
        return user != null && ADMIN_EMAIL.equals(user.getUsername());
    }

    // ✅ Create a new wash package
    @PostMapping
    public ResponseEntity<WashPackageDTO> addWashPackage(
            @AuthenticationPrincipal User user,
            @RequestBody WashPackageDTO dto) {

        if (!isAuthorized(user)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(cartClient.add(dto));
    }

    // ✅ Update an existing wash package
    @PutMapping("/{id}")
    public ResponseEntity<WashPackageDTO> updateWashPackage(
            @AuthenticationPrincipal User user,
            @PathVariable Long id,
            @RequestBody WashPackageDTO dto) {

        if (!isAuthorized(user)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(cartClient.update(id, dto));
    }

    // ✅ Delete a wash package
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteWashPackage(
            @AuthenticationPrincipal User user,
            @PathVariable Long id) {

        if (!isAuthorized(user)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Unauthorized access");
        }

        cartClient.delete(id);
        return ResponseEntity.ok("Deleted successfully.");
    }

    // ✅ Get wash package by ID
    @GetMapping("/{id}")
    public ResponseEntity<WashPackageDTO> getById(
            @AuthenticationPrincipal User user,
            @PathVariable Long id) {

        if (!isAuthorized(user)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(cartClient.getById(id));
    }

    // ✅ Get all wash packages
    @GetMapping
    public ResponseEntity<List<WashPackageDTO>> getAll(
            @AuthenticationPrincipal User user) {

        if (!isAuthorized(user)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        return ResponseEntity.ok(cartClient.getAll());
    }
    
    
   

}
