package com.example.adminservicee;


import com.example.adminservice.client.CartServiceClient;
import com.example.adminservice.client.OrderClient;
import com.example.adminservice.controller.AdminController;
import com.example.adminservice.controller.AdminRatingsController;
import com.example.adminservice.controller.AuthController;
import com.example.adminservice.dto.LeaderboardDTO;
import com.example.adminservice.dto.LoginRequest;
import com.example.adminservice.dto.WashPackageDTO;
import com.example.adminservice.security.JwtUtil;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.User;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class AdminServiceControllersTests {

    private AuthController authController;
    private JwtUtil jwtUtilMock;

    private AdminController adminController;
    private CartServiceClient cartClientMock;

    private AdminRatingsController ratingsController;
    private OrderClient orderClientMock;

    private User adminUser;
    private User nonAdminUser;

    @BeforeEach
    void setUp() {
        // Mocks for AuthController
        jwtUtilMock = mock(JwtUtil.class);
        authController = new AuthController(jwtUtilMock);

        // Mocks for AdminController
        cartClientMock = mock(CartServiceClient.class);
        adminController = new AdminController();
        // Use reflection to inject private field
        try {
            var field = AdminController.class.getDeclaredField("cartClient");
            field.setAccessible(true);
            field.set(adminController, cartClientMock);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Mocks for AdminRatingsController
        orderClientMock = mock(OrderClient.class);
        ratingsController = new AdminRatingsController();
        try {
            var field = AdminRatingsController.class.getDeclaredField("orderClient");
            field.setAccessible(true);
            field.set(ratingsController, orderClientMock);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        // Users
        adminUser = new User("admin@wash.com", "", List.of());
        nonAdminUser = new User("user@wash.com", "", List.of());
    }

    // ================== AuthController Tests ==================
    @Test
    void testAuthController_LoginSuccess() {
        LoginRequest request = new LoginRequest("admin@wash.com", "Ksj*242818");
        when(jwtUtilMock.generateToken(request.getEmail(), "ADMIN")).thenReturn("mocked_jwt_token");

        ResponseEntity<?> response = authController.login(request);

        assertEquals(200, response.getStatusCodeValue());
        assertTrue(response.getBody().toString().contains("mocked_jwt_token"));
        verify(jwtUtilMock, times(1)).generateToken(request.getEmail(), "ADMIN");
    }

    @Test
    void testAuthController_LoginFailure() {
        LoginRequest request = new LoginRequest("user@wash.com", "wrongpass");

        ResponseEntity<?> response = authController.login(request);

        assertEquals(401, response.getStatusCodeValue());
        assertEquals("Invalid credentials", response.getBody());
        verify(jwtUtilMock, never()).generateToken(anyString(), anyString());
    }

    @Test
    void testAuthController_Logout() {
        ResponseEntity<?> response = authController.logout("Bearer token");
        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Logged out successfully. Please discard the token on client side.", response.getBody());
    }

    // ================== AdminController Tests ==================
    @Test
    void testAdminController_AddWashPackage_AdminUser() {
        WashPackageDTO dto = new WashPackageDTO("Basic", "Exterior", "Simple wash", 100);
        when(cartClientMock.add(dto)).thenReturn(dto);

        ResponseEntity<WashPackageDTO> response = adminController.addWashPackage(adminUser, dto);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(dto, response.getBody());
        verify(cartClientMock, times(1)).add(dto);
    }

    @Test
    void testAdminController_AddWashPackage_NonAdminUser() {
        WashPackageDTO dto = new WashPackageDTO();
        ResponseEntity<WashPackageDTO> response = adminController.addWashPackage(nonAdminUser, dto);

        assertEquals(401, response.getStatusCodeValue());
        verify(cartClientMock, never()).add(any());
    }

    @Test
    void testAdminController_DeleteWashPackage_AdminUser() {
        Long id = 1L;
        doNothing().when(cartClientMock).delete(id);

        ResponseEntity<String> response = adminController.deleteWashPackage(adminUser, id);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals("Deleted successfully.", response.getBody());
        verify(cartClientMock, times(1)).delete(id);
    }

    // ================== AdminRatingsController Tests ==================
    @Test
    void testAdminRatingsController_GetLeaderboard_AdminUser() {
        List<LeaderboardDTO> mockList = Arrays.asList(new LeaderboardDTO(1, "washer@example.com", 4.5));
        when(orderClientMock.getLeaderboard()).thenReturn(mockList);

        ResponseEntity<?> response = ratingsController.getLeaderboard(adminUser);

        assertEquals(200, response.getStatusCodeValue());
        assertEquals(mockList, response.getBody());
        verify(orderClientMock, times(1)).getLeaderboard();
    }

    @Test
    void testAdminRatingsController_GetLeaderboard_NonAdminUser() {
        ResponseEntity<?> response = ratingsController.getLeaderboard(nonAdminUser);

        assertEquals(401, response.getStatusCodeValue());
        assertEquals("Unauthorized access", response.getBody());
        verify(orderClientMock, never()).getLeaderboard();
    }
}
