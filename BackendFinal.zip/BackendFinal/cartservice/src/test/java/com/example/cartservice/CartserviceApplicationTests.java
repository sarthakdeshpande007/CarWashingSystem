package com.example.cartservice;

import com.example.cartservice.controller.WashPackageController;
import com.example.cartservice.entity.WashPackage;
import com.example.cartservice.exception.ResourceNotFoundException;
import com.example.cartservice.repository.WashPackageRepository;
import com.example.cartservice.service.WashPackageService;
import com.example.cartservice.service.impl.WashPackageServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class CartserviceApplicationTests {

    @Mock
    private WashPackageService service;

    @Mock
    private WashPackageRepository repository;

    @InjectMocks
    private WashPackageServiceImpl serviceImpl;

    @InjectMocks
    private WashPackageController controller;

    private WashPackage samplePackage;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        samplePackage = new WashPackage("Basic Wash", "Interior", "Interior cleaning", 500.0);
        samplePackage.setId(1L);
    }

    // ---------------- Controller Tests ----------------
    @Test
    void testAddPackage_Controller() {
        when(service.add(any(WashPackage.class))).thenReturn(samplePackage);

        ResponseEntity<WashPackage> response = controller.addPackage(samplePackage);

        assertEquals(samplePackage, response.getBody());
        verify(service, times(1)).add(samplePackage);
    }

    @Test
    void testUpdatePackage_Controller() {
        when(service.update(eq(1L), any(WashPackage.class))).thenReturn(samplePackage);

        ResponseEntity<WashPackage> response = controller.updatePackage(1L, samplePackage);

        assertEquals(samplePackage, response.getBody());
        verify(service, times(1)).update(1L, samplePackage);
    }

    @Test
    void testDeletePackage_Controller() {
        doNothing().when(service).delete(1L);

        ResponseEntity<String> response = controller.deletePackage(1L);

        assertEquals("Package deleted", response.getBody());
        verify(service, times(1)).delete(1L);
    }

    @Test
    void testGetById_Controller() {
        when(service.getById(1L)).thenReturn(samplePackage);

        ResponseEntity<WashPackage> response = controller.getById(1L);

        assertEquals(samplePackage, response.getBody());
        verify(service, times(1)).getById(1L);
    }

    @Test
    void testGetAll_Controller() {
        List<WashPackage> packages = Arrays.asList(samplePackage);
        when(service.getAll()).thenReturn(packages);

        ResponseEntity<List<WashPackage>> response = controller.getAll();

        assertEquals(packages, response.getBody());
        verify(service, times(1)).getAll();
    }

    // ---------------- Service Tests ----------------
    @Test
    void testAdd_Service() {
        when(repository.save(any(WashPackage.class))).thenReturn(samplePackage);

        WashPackage result = serviceImpl.add(samplePackage);

        assertEquals(samplePackage, result);
        verify(repository, times(1)).save(samplePackage);
    }

    @Test
    void testUpdate_Service() {
        when(repository.findById(1L)).thenReturn(Optional.of(samplePackage));
        when(repository.save(any(WashPackage.class))).thenReturn(samplePackage);

        WashPackage updated = new WashPackage("Updated Wash", "Exterior", "Updated details", 1200.0);
        WashPackage result = serviceImpl.update(1L, updated);

        assertEquals("Updated Wash", result.getPackageName());
        verify(repository, times(1)).findById(1L);
        verify(repository, times(1)).save(any(WashPackage.class));
    }

    @Test
    void testUpdate_Service_NotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        WashPackage updated = new WashPackage("Any", "Any", "Any", 0.0);

        assertThrows(ResourceNotFoundException.class, () -> serviceImpl.update(2L, updated));
    }

    @Test
    void testDelete_Service() {
        when(repository.existsById(1L)).thenReturn(true);
        doNothing().when(repository).deleteById(1L);

        assertDoesNotThrow(() -> serviceImpl.delete(1L));
        verify(repository, times(1)).deleteById(1L);
    }

    @Test
    void testDelete_Service_NotFound() {
        when(repository.existsById(2L)).thenReturn(false);

        assertThrows(ResourceNotFoundException.class, () -> serviceImpl.delete(2L));
    }

    @Test
    void testGetById_Service() {
        when(repository.findById(1L)).thenReturn(Optional.of(samplePackage));

        WashPackage result = serviceImpl.getById(1L);

        assertEquals(samplePackage, result);
        verify(repository, times(1)).findById(1L);
    }

    @Test
    void testGetById_Service_NotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> serviceImpl.getById(2L));
    }

    @Test
    void testGetAll_Service() {
        when(repository.findAll()).thenReturn(Arrays.asList(samplePackage));

        var result = serviceImpl.getAll();

        assertEquals(1, result.size());
        verify(repository, times(1)).findAll();
    }
}
