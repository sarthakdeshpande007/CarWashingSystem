package com.example.cartservice.controller;

import com.example.cartservice.entity.WashPackage;
import com.example.cartservice.service.WashPackageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/wash-packages")
@CrossOrigin(origins = "*")
public class WashPackageController {

    @Autowired
    private WashPackageService service;

    @PostMapping
    public ResponseEntity<WashPackage> addPackage(@RequestBody WashPackage washPackage) {
        return ResponseEntity.ok(service.add(washPackage));
    }

    @PutMapping("/{id}")
    public ResponseEntity<WashPackage> updatePackage(@PathVariable Long id, @RequestBody WashPackage washPackage) {
        return ResponseEntity.ok(service.update(id, washPackage));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deletePackage(@PathVariable Long id) {
        service.delete(id);
        return ResponseEntity.ok("Package deleted");
    }

    @GetMapping("/{id}")
    public ResponseEntity<WashPackage> getById(@PathVariable Long id) {
        return ResponseEntity.ok(service.getById(id));
    }

    @GetMapping
    public ResponseEntity<List<WashPackage>> getAll() {
        return ResponseEntity.ok(service.getAll());
    }
}
