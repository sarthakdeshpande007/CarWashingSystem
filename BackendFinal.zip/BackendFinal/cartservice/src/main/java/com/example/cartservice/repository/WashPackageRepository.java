package com.example.cartservice.repository;

import com.example.cartservice.entity.WashPackage;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface WashPackageRepository extends JpaRepository<WashPackage, Long> {
    // No custom methods needed for basic CRUD
}
