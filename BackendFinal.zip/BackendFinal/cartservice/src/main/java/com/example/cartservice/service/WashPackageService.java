package com.example.cartservice.service;

import com.example.cartservice.entity.WashPackage;

import java.util.List;

public interface WashPackageService {
    WashPackage add(WashPackage washPackage);
    WashPackage update(Long id, WashPackage washPackage);
    void delete(Long id);
    WashPackage getById(Long id);
    List<WashPackage> getAll();
}
