package com.example.cartservice.entity; // change to 'cartservice.entity' in Cart Service

import jakarta.persistence.*;

@Entity
@Table(name = "wash_packages")
public class WashPackage {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String packageName;
    private String packageType;
    private String details;
    private double cost;

    /*public WashPackage(long l, String string, String string2, String string3, double d) {
    }*/
    
    public WashPackage() {
    }

    public WashPackage(String packageName, String packageType, String details, double cost) {
        this.packageName = packageName;
        this.packageType = packageType;
        this.details = details;
        this.cost = cost;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public String getPackageType() {
        return packageType;
    }

    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public double getCost() {
        return cost;
    }

    public void setCost(double cost) {
        this.cost = cost;
    }
}
