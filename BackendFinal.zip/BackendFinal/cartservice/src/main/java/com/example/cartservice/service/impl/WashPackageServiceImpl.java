package com.example.cartservice.service.impl;

import com.example.cartservice.entity.WashPackage;
import com.example.cartservice.exception.ResourceNotFoundException;
import com.example.cartservice.repository.WashPackageRepository;
import com.example.cartservice.service.WashPackageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class WashPackageServiceImpl implements WashPackageService {

    @Autowired
    private WashPackageRepository repository;

    @Override
    public WashPackage add(WashPackage washPackage) {
        washPackage.setId(null); // Ensure new row is created
        return repository.save(washPackage);
    }

    @Override
    public WashPackage update(Long id, WashPackage updated) {
        WashPackage existing = repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Package not found with id: " + id));
        existing.setPackageName(updated.getPackageName());
        existing.setPackageType(updated.getPackageType());
        existing.setDetails(updated.getDetails());
        existing.setCost(updated.getCost());
        return repository.save(existing);
    }

    @Override
    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Cannot delete. Package not found with id: " + id);
        }
        repository.deleteById(id);
    }

    @Override
    public WashPackage getById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Package not found with id: " + id));
    }

    @Override
    public List<WashPackage> getAll() {
        return repository.findAll();
    }
}
