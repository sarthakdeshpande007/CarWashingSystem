package com.example.washerservice;


import com.example.washerservice.dto.LoginRequest;
import com.example.washerservice.dto.WasherDTO;
import com.example.washerservice.entity.Washer;
import com.example.washerservice.repository.WasherRepository;
import com.example.washerservice.security.JwtUtil;
import com.example.washerservice.service.WasherServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

class WasherServiceTest {

    @Mock
    private WasherRepository repository;

    @Mock
    private BCryptPasswordEncoder encoder;

    @Mock
    private JwtUtil jwtUtil;

    @InjectMocks
    private WasherServiceImpl washerService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void testRegisterSuccess() {
        WasherDTO dto = new WasherDTO();
        dto.setEmail("test@example.com");
        dto.setUsername("tester");
        dto.setPhoneNo("9876543210");
        dto.setPassword("Password@1");

        when(repository.findByEmail(dto.getEmail())).thenReturn(Optional.empty());
        when(repository.findByUsername(dto.getUsername())).thenReturn(Optional.empty());
        when(encoder.encode(dto.getPassword())).thenReturn("hashedPassword");

        String result = washerService.register(dto);
        assertEquals("Washer registered successfully!", result);
        verify(repository, times(1)).save(any(Washer.class));
    }

    @Test
    void testLoginSuccess() {
        LoginRequest login = new LoginRequest();
        login.setEmail("test@example.com");
        login.setPassword("Password@1");

        Washer washer = new Washer();
        washer.setEmail("test@example.com");
        washer.setPassword("hashedPassword");

        when(repository.findByEmail(login.getEmail())).thenReturn(Optional.of(washer));
        when(encoder.matches(login.getPassword(), washer.getPassword())).thenReturn(true);
        when(jwtUtil.generateToken(washer.getEmail(), "WASHER")).thenReturn("mockToken");

        String token = washerService.login(login);
        assertEquals("mockToken", token);
    }

    @Test
    void testLoginInvalidPassword() {
        LoginRequest login = new LoginRequest();
        login.setEmail("test@example.com");
        login.setPassword("wrongPassword");

        Washer washer = new Washer();
        washer.setEmail("test@example.com");
        washer.setPassword("hashedPassword");

        when(repository.findByEmail(login.getEmail())).thenReturn(Optional.of(washer));
        when(encoder.matches(login.getPassword(), washer.getPassword())).thenReturn(false);

        String result = washerService.login(login);
        assertEquals("Invalid credentials.", result);
    }

}
