package com.example.washerservice.dto;

public class WasherIndividualRatingDTO {
    private String customerEmail;
    private int rating;
    private String review;

    public WasherIndividualRatingDTO() {}

    public WasherIndividualRatingDTO(String customerEmail, int rating, String review) {
        this.customerEmail = customerEmail;
        this.rating = rating;
        this.review = review;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }

    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public int getRating() {
        return rating;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }
}
