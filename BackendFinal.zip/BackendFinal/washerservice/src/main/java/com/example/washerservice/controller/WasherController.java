package com.example.washerservice.controller;
import com.example.washerservice.dto.LoginRequest;
import com.example.washerservice.dto.WasherDTO;
import com.example.washerservice.dto.WasherIndividualRatingDTO;
import com.example.washerservice.dto.WasherPublicDTO;
import com.example.washerservice.dto.WasherRatingDTO;
import com.example.washerservice.entity.Washer;
import com.example.washerservice.repository.WasherRepository;
import com.example.washerservice.security.JwtUtil;
import com.example.washerservice.service.WasherService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;

import com.example.washerservice.dto.FeedbackDTO;
import com.example.washerservice.dto.FeedbackRequestDTO;
import com.example.washerservice.dto.InvoiceRequestDTO;
import com.example.washerservice.dto.LeaderboardDTO;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.example.washerservice.client.OrderClient;
import com.example.washerservice.dto.Order;
@RestController
@RequestMapping("/api/washers")
@SecurityRequirement(name = "bearerAuth")
public class WasherController {

    @Autowired
    private WasherService washerService;

    @Autowired
    private JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody WasherDTO dto) {
        return washerService.register(dto);
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest login) {
        return washerService.login(login);
    }

    @PostMapping("/logout")
    public String logout(@RequestHeader("Authorization") String token) {
        return washerService.logout(token);
    }

    /*
    @PutMapping("/update")
    public String updateProfile(@AuthenticationPrincipal User user, @RequestBody WasherDTO dto) {
        return washerService.updateProfile(user.getUsername(), dto);
    }

    
    @GetMapping("/profile")
    public ResponseEntity<WasherDTO> getProfile(@AuthenticationPrincipal User user) {
        WasherDTO washerProfile = washerService.getProfile(user.getUsername());
        return ResponseEntity.ok(washerProfile);
    }

    */
    
    @PutMapping("/update")
    public ResponseEntity<String> updateProfile(@AuthenticationPrincipal User user, 
                                                @RequestBody WasherDTO dto) {
        String response = washerService.updateProfile(user.getUsername(), dto);
        return ResponseEntity.ok(response);
    }

    // ✅ Get profile of logged-in washer
    @GetMapping("/profile")
    public ResponseEntity<WasherDTO> getProfile(@AuthenticationPrincipal User user) {
        WasherDTO washerProfile = washerService.getProfile(user.getUsername());
        return ResponseEntity.ok(washerProfile);
    }
    
    
    
    @DeleteMapping("/delete")
    public String deleteAccount(@AuthenticationPrincipal User user) {
        return washerService.deleteAccount(user.getUsername());
    }
    
   

    @PostMapping("/send")
    public String sendInvoice(@RequestBody InvoiceRequestDTO dto) {
        return washerService.sendInvoiceWithPdf(dto);
    }
    
    @Autowired
    private OrderClient orderClient;

    @GetMapping("/orders")
    public ResponseEntity<List<Order>> getOrders(@AuthenticationPrincipal User user,
                                                 @RequestParam String type) {
        String washerEmail = user.getUsername(); // From JWT
        return ResponseEntity.ok(orderClient.getOrdersByWasher(washerEmail, type));
    }

    @PutMapping("/orders/{orderId}/status")
    public ResponseEntity<Order> updateOrderStatus(@AuthenticationPrincipal User user,
                                                   @PathVariable Long orderId,
                                                   @RequestParam String newStatus) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.updateOrderStatus(orderId, washerEmail, newStatus));
    }
    
    
    
    
   

  

    @PostMapping("/orders/{orderId}/feedback")
    public ResponseEntity<String> giveFeedback(@AuthenticationPrincipal User user,
                                               @PathVariable Long orderId,
                                               @RequestBody FeedbackRequestDTO dto) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.submitFeedback(orderId, dto, washerEmail));
    }

    @PutMapping("/feedback/{id}/edit")
    public ResponseEntity<String> editFeedback(@AuthenticationPrincipal User user,
                                               @PathVariable Long id,
                                               @RequestBody FeedbackRequestDTO dto) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.editFeedback(id, dto, washerEmail));
    }


    // ✅ Delete Feedback
    @DeleteMapping("/feedback/{id}")
    public ResponseEntity<String> deleteFeedback(@AuthenticationPrincipal User user,
                                                 @PathVariable Long id) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.deleteFeedback(id, washerEmail));
    }

    // ✅ View Single Feedback
    @GetMapping("/feedback/{id}")
    public ResponseEntity<FeedbackDTO> getFeedbackById(@AuthenticationPrincipal User user,
                                                       @PathVariable Long id) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.getFeedbackById(id, washerEmail));
    }

    @GetMapping("/feedback/all")
    public ResponseEntity<List<FeedbackDTO>> getAllMyFeedbacks(@AuthenticationPrincipal User user) {
        String washerEmail = user.getUsername();
        return ResponseEntity.ok(orderClient.getAllFeedbacks(washerEmail));
    }

    
    @GetMapping("/orders/{orderId}/feedback")
    public ResponseEntity<FeedbackDTO> getFeedbackForOrder(@AuthenticationPrincipal User user,
                                                           @PathVariable Long orderId) {
        String washerEmail = user.getUsername(); // from JWT
        return ResponseEntity.ok(orderClient.getFeedbackByOrderId(orderId, washerEmail));
    }


    @GetMapping("/rating/leaderboard")
    public ResponseEntity<List<LeaderboardDTO>> viewLeaderboard() {
        List<LeaderboardDTO> leaderboard = orderClient.getLeaderboard();
        return ResponseEntity.ok(leaderboard);
    }

    // ✅ View my individual ratings
    @GetMapping("/rating/my-ratings")
    public ResponseEntity<List<WasherIndividualRatingDTO>> getMyRatings(@AuthenticationPrincipal User user) {
        String washerEmail = user.getUsername(); // Extracted from JWT
        List<WasherIndividualRatingDTO> ratings = orderClient.getRatingsGivenToMe(washerEmail);
        return ResponseEntity.ok(ratings);
    }
    
    
    @Autowired
    private WasherRepository washerRepository;
    
    @GetMapping("/public/all")
    public ResponseEntity<List<Map<String, String>>> getAllWashers() {
        List<Washer> washers = washerRepository.findAll();

        List<Map<String, String>> result = washers.stream().map(washer -> {
            Map<String, String> map = new HashMap<>();
            map.put("username", washer.getUsername());
            map.put("email", washer.getEmail());
            map.put("phoneNo", washer.getPhoneNo());
            return map;
        }).collect(Collectors.toList());

        return ResponseEntity.ok(result);
    }


  
}
