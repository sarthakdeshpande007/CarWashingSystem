package com.example.washerservice.service;
import com.example.washerservice.dto.InvoiceRequestDTO;
import com.example.washerservice.dto.LoginRequest;
import com.example.washerservice.dto.WasherDTO;
import com.example.washerservice.dto.WasherPublicDTO;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;
import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.util.Map;
import com.example.washerservice.dto.InvoiceRequestDTO;
import com.example.washerservice.dto.LoginRequest;
import com.example.washerservice.dto.WasherDTO;
import com.example.washerservice.entity.Washer;
import com.example.washerservice.repository.WasherRepository;
import com.example.washerservice.security.JwtUtil;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.stream.Collectors;
import java.util.List;

import java.io.ByteArrayOutputStream;
import java.util.Map;
import java.util.Optional;
import java.util.regex.Pattern;
import org.springframework.transaction.annotation.Transactional;
@Service
public class WasherServiceImpl implements WasherService {

    @Autowired
    private WasherRepository repository;

    @Autowired
    private BCryptPasswordEncoder encoder;

    @Autowired
    private JwtUtil jwtUtil;

    private final Pattern emailPattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private final Pattern phonePattern = Pattern.compile("^\\d{10}$");
    private final Pattern passwordPattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$");

    @Override
    public String register(WasherDTO dto) {
        if (!emailPattern.matcher(dto.getEmail()).matches()) {
            return "Invalid email format.";
        }
        if (!phonePattern.matcher(dto.getPhoneNo()).matches()) {
            return "Phone number must be 10 digits.";
        }
        if (!passwordPattern.matcher(dto.getPassword()).matches()) {
            return "Password must be strong (at least 8 characters with upper/lowercase, number, special char).";
        }
        if (repository.findByEmail(dto.getEmail()).isPresent()) {
            return "Email already registered.";
        }
        if (repository.findByUsername(dto.getUsername()).isPresent()) {
            return "Username already taken.";
        }

        Washer washer = new Washer();
        washer.setEmail(dto.getEmail());
        washer.setUsername(dto.getUsername());
        washer.setPhoneNo(dto.getPhoneNo());
        washer.setPassword(encoder.encode(dto.getPassword()));

        repository.save(washer);
        return "Washer registered successfully!";
    }

   
    /*public String login(LoginRequest login) {
        Optional<Washer> washerOpt = repository.findByEmail(login.getEmail());
        if (washerOpt.isEmpty()) return "Invalid credentials.";

        Washer washer = washerOpt.get();
        if (encoder.matches(login.getPassword(), washer.getPassword())) {
            return jwtUtil.generateToken(washer.getEmail());
        } else {
            return "Invalid credentials.";
        }
    }*/
    
    
    @Override
    public String login(LoginRequest login) {
        Optional<Washer> washerOpt = repository.findByEmail(login.getEmail());
        if (washerOpt.isEmpty()) return "Invalid credentials.";

        Washer washer = washerOpt.get();
        if (encoder.matches(login.getPassword(), washer.getPassword())) {
            // Pass role explicitly
            return jwtUtil.generateToken(washer.getEmail(), "WASHER");
        } else {
            return "Invalid credentials.";
        }
    }

    

    @Override
    public String logout(String token) {
        return "Logged out. Discard the token on client.";
    }

    
   /* public String updateProfile(String email, WasherDTO dto) {
        Optional<Washer> washerOpt = repository.findByEmail(email);
        if (washerOpt.isEmpty()) return "User not found.";

        Washer washer = washerOpt.get();
        if (!dto.getEmail().equalsIgnoreCase(email)) {
            return "Email update is not allowed.";
        }
        if (!phonePattern.matcher(dto.getPhoneNo()).matches()) {
            return "Phone number must be 10 digits.";
        }
        if (!passwordPattern.matcher(dto.getPassword()).matches()) {
            return "Password must be strong.";
        }

        // Email should not be updated
        washer.setUsername(dto.getUsername());
        washer.setPhoneNo(dto.getPhoneNo());
        washer.setPassword(encoder.encode(dto.getPassword()));

        repository.save(washer);
        return "Profile updated successfully.";
    }*/
    
   

    @Override
    public String updateProfile(String email, WasherDTO dto) {
        Optional<Washer> washerOpt = repository.findByEmail(email);
        if (washerOpt.isEmpty()) {
            return "User not found.";
        }

        Washer washer = washerOpt.get();

        // Email update not allowed
        if (dto.getEmail() != null && !dto.getEmail().equalsIgnoreCase(email)) {
            return "Email update is not allowed.";
        }

        boolean updated = false;

        // Username update
        if (dto.getUsername() != null && !dto.getUsername().isBlank()) {
            washer.setUsername(dto.getUsername());
            updated = true;
        }

        // Phone validation + update
        if (dto.getPhoneNo() != null && !dto.getPhoneNo().isBlank()) {
            if (!phonePattern.matcher(dto.getPhoneNo()).matches()) {
                return "Phone number must be 10 digits.";
            }
            washer.setPhoneNo(dto.getPhoneNo());
            updated = true;
        }

        // Password validation + update
        if (dto.getPassword() != null && !dto.getPassword().isBlank()) {
            if (!passwordPattern.matcher(dto.getPassword()).matches()) {
                return "Password must be strong (8+ chars, 1 uppercase, 1 digit, 1 special char).";
            }
            washer.setPassword(encoder.encode(dto.getPassword()));
            updated = true;
        }

        if (!updated) {
            return "No changes provided to update.";
        }

        repository.save(washer);
        return "Profile updated successfully.";
    }


    public WasherDTO getProfile(String email) {
        Optional<Washer> washerOpt = repository.findByEmail(email);
        if (washerOpt.isEmpty()) {
            return null; // controller will handle 404
        }
        Washer washer = washerOpt.get();
        return new WasherDTO(
                washer.getEmail(),
                washer.getUsername(),
                washer.getPhoneNo(),
                "" // never return password in profile response
        );
    }
    
    @Override
    @Transactional  
    public String deleteAccount(String email) {
        if (repository.findByEmail(email).isEmpty()) return "User not found.";
        repository.deleteByEmail(email);
        return "Account deleted successfully.";
    }
    
    
    @Autowired
    private JavaMailSender mailSender;

    @Override
    public String sendInvoiceWithPdf(InvoiceRequestDTO dto) {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();

            Document document = new Document();
            PdfWriter.getInstance(document, out);
            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20);
            Paragraph title = new Paragraph("Car Wash Invoice", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);
            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(2);
            table.setWidthPercentage(100);
            table.setSpacingBefore(10f);

            // Customer & Washer Info
            addRow(table, "Order ID", String.valueOf(dto.getOrderId()));
            addRow(table, "Customer Name", dto.getCustomerName());
            addRow(table, "Customer ID", String.valueOf(dto.getCustomerId()));
            addRow(table, "Washer Name", dto.getWasherName());
            addRow(table, "Washer ID", String.valueOf(dto.getWasherId()));

            // Package with amount
            addRow(table, "Package", dto.getPackageName() + " - ₹" + dto.getPackageAmount());

            // Add-ons with amounts
            if (dto.getAddons() != null && !dto.getAddons().isEmpty()) {
                StringBuilder addonDetails = new StringBuilder();
                for (Map.Entry<String, Double> entry : dto.getAddons().entrySet()) {
                    addonDetails.append(entry.getKey())
                            .append(" - ₹")
                            .append(entry.getValue())
                            .append("\n");
                }
                addRow(table, "Add-ons", addonDetails.toString().trim());
            } else {
                addRow(table, "Add-ons", "None");
            }

            addRow(table, "Tax", "₹" + dto.getTax());
            addRow(table, "Total Amount", "₹" + dto.getTotalAmount());

            document.add(table);
            document.close();

            // Email with attachment
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true);

            helper.setTo(dto.getCustomerEmail());
            helper.setSubject("Car Wash Invoice - Order ID: " + dto.getOrderId());
            helper.setText("Dear " + dto.getCustomerName() + ",\n\nPlease find attached your invoice.", false);

            helper.addAttachment("invoice_order_" + dto.getOrderId() + ".pdf",
                    new ByteArrayResource(out.toByteArray()));

            mailSender.send(message);

            return "Invoice sent to " + dto.getCustomerEmail();

        } catch (MessagingException | DocumentException e) {
            e.printStackTrace();
            return "Failed to send invoice: " + e.getMessage();
        }
    }

    private void addRow(PdfPTable table, String key, String value) {
        table.addCell(new PdfPCell(new Phrase(key)));
        table.addCell(new PdfPCell(new Phrase(value)));
    }

    
    @Autowired
    private WasherRepository washerRepository;
    @Override
    public List<WasherPublicDTO> getAllPublicWashers() {
        List<Washer> washers = washerRepository.findAll();

        return washers.stream()
            .map(w -> new WasherPublicDTO(
                w.getId(),
                w.getUsername(),
                w.getEmail(),
                w.getPhoneNo()
            ))
            .collect(Collectors.toList());
    }

	
}
