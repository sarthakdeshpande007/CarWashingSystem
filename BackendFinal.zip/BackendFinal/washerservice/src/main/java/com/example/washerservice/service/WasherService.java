package com.example.washerservice.service;

import java.util.List;

import com.example.washerservice.dto.InvoiceRequestDTO;
import com.example.washerservice.dto.LoginRequest;
import com.example.washerservice.dto.WasherDTO;
import com.example.washerservice.dto.WasherPublicDTO;
import com.example.washerservice.entity.Washer;

public interface WasherService {
    String register(WasherDTO dto);
    String login(LoginRequest login);
    String logout(String token);
    String updateProfile(String email, WasherDTO dto);
    String deleteAccount(String email);
	String sendInvoiceWithPdf(InvoiceRequestDTO dto);
	public WasherDTO getProfile(String email);

	List<WasherPublicDTO> getAllPublicWashers();

	

}
