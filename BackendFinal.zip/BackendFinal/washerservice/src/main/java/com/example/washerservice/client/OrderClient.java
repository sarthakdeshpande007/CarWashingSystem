package com.example.washerservice.client;


import com.example.washerservice.dto.FeedbackDTO;
import com.example.washerservice.dto.FeedbackRequestDTO;
import com.example.washerservice.dto.LeaderboardDTO;
import com.example.washerservice.dto.Order;
import com.example.washerservice.dto.WasherIndividualRatingDTO;
import com.example.washerservice.dto.WasherRatingDTO;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@FeignClient(name = "orderservice", url = "http://localhost:8084")
public interface OrderClient {

    @GetMapping("/orders/washer")
    List<Order> getOrdersByWasher(
        @RequestParam("washerEmail") String washerEmail,
        @RequestParam("status") String status);

    @PutMapping("/orders/washer/{orderId}/status")
    Order updateOrderStatus(
        @PathVariable("orderId") Long orderId,
        @RequestParam("washerEmail") String washerEmail,
        @RequestParam("newStatus") String newStatus);
    
    
    
    @PostMapping("/feedback/submit/{orderId}")
    String submitFeedback(@PathVariable("orderId") Long orderId,
                          @RequestBody FeedbackRequestDTO dto,
                          @RequestHeader("washerEmail") String washerEmail);

    @PutMapping("/feedback/{id}/edit")
    String editFeedback(@PathVariable("id") Long id,
                        @RequestBody FeedbackRequestDTO dto,
                        @RequestHeader("washerEmail") String washerEmail);

    
    
 
    @DeleteMapping("/feedback/{id}")
    String deleteFeedback(@PathVariable("id") Long id, @RequestHeader("washerEmail") String washerEmail);

    
    @GetMapping("/feedback/{id}")
    FeedbackDTO getFeedbackById(@PathVariable("id") Long id,
                                @RequestHeader("washerEmail") String washerEmail);

    @GetMapping("/feedback/all")
    List<FeedbackDTO> getAllFeedbacks(@RequestHeader("washerEmail") String washerEmail);
 
    @GetMapping("/feedback/order/{orderId}")
    FeedbackDTO getFeedbackByOrderId(@PathVariable("orderId") Long orderId,
                                     @RequestHeader("washerEmail") String washerEmail);
    
    
    @GetMapping("/orders/rating/leaderboard") // ✅ Correct path
    List<LeaderboardDTO> getLeaderboard();

    @GetMapping("/orders/rating/my-ratings")
    List<WasherIndividualRatingDTO> getRatingsGivenToMe(
            @RequestHeader("washerEmail") String washerEmail);



}

