package com.example.washerservice.dto;
/*
public class WasherDTO {
    private String email;
    private String username;
    private String password;
    private String phoneNo;

    // Getters and Setters
    public String getEmail() { return email; }

   

    public String getUsername() { return username; }

    public void setUsername(String username) { this.username = username; }

    public String getPassword() { return password; }

    public void setPassword(String password) { this.password = password; }

    public String getPhoneNo() { return phoneNo; }

    public void setPhoneNo(String phoneNo) { this.phoneNo = phoneNo; }
}*/


public class WasherDTO {
    private String email;
    private String username;
    private String phoneNo;
    private String password;

    public WasherDTO() {}

    public WasherDTO(String email, String username, String phoneNo, String password) {
        this.email = email;
        this.username = username;
        this.phoneNo = phoneNo;
        this.password = password;
    }

    // Getters and Setters
    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPhoneNo() {
        return phoneNo;
    }

    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}

