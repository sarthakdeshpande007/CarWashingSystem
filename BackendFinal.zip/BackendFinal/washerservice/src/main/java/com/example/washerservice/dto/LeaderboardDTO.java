// LeaderboardDTO.java
package com.example.washerservice.dto;

public class LeaderboardDTO {
    private int rank;
    private String washerEmail;
    private double averageRating;
    private long totalRatings;

    public LeaderboardDTO() {}
    public LeaderboardDTO(int rank, String washerEmail, double averageRating, long totalRatings) {
        this.rank = rank;
        this.washerEmail = washerEmail;
        this.averageRating = averageRating;
        this.totalRatings = totalRatings;
    }

    public int getRank() { return rank; }
    public String getWasherEmail() { return washerEmail; }
    public double getAverageRating() { return averageRating; }
    public long getTotalRatings() { return totalRatings; }

    public void setRank(int rank) { this.rank = rank; }
    public void setWasherEmail(String washerEmail) { this.washerEmail = washerEmail; }
    public void setAverageRating(double averageRating) { this.averageRating = averageRating; }
    public void setTotalRatings(long totalRatings) { this.totalRatings = totalRatings; }
}
