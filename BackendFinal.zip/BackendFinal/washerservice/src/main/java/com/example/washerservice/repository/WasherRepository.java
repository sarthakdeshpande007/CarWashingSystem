package com.example.washerservice.repository;

import com.example.washerservice.entity.Washer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface WasherRepository extends JpaRepository<Washer, Long> {
    Optional<Washer> findByEmail(String email);
    Optional<Washer> findByUsername(String username);
    void deleteByEmail(String email);
}
