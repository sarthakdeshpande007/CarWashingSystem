package com.example.customerservice.dto;

public class LoginRequest {
    public LoginRequest(String string, String string2) {
		// TODO Auto-generated constructor stub
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	private String email;
    private String password;

    // Getters and Setters
    // ... (omit for brevity)
}