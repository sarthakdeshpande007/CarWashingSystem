package com.example.customerservice.feign;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.customerservice.dto.PaymentRequest;

//package: com.example.customerservice.feign

@FeignClient(name = "paymentservice") // This matches the application name registered in Eureka
public interface PaymentClient {

 @PostMapping("/api/payments/initiate")
 String initiatePayment(@RequestBody PaymentRequest request);
}
