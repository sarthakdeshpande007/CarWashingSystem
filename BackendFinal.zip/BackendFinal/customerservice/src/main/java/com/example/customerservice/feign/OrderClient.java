package com.example.customerservice.feign;


import com.example.customerservice.dto.FeedbackDTO;
import com.example.customerservice.dto.LeaderboardDTO;
import com.example.customerservice.dto.OrderRequestDTO;
import com.example.customerservice.dto.RatingRequestDTO;
import com.example.customerservice.dto.WasherRatingDTO;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

// Connects to OrderService running on port 8084
@FeignClient(name = "orderservice", url = "http://localhost:8084/orders")
public interface OrderClient {

    @PostMapping
    ResponseEntity<String> placeOrder(@RequestBody OrderRequestDTO order);

    @GetMapping("/status")
    List<Object> getOrdersByStatus(@RequestParam String email, @RequestParam String status);

    @PutMapping("/{id}")
    ResponseEntity<String> updateOrder(@PathVariable("id") Long id,
                                       @RequestParam String email,
                                       @RequestBody OrderRequestDTO updatedOrder);

    @DeleteMapping("/{id}")
    ResponseEntity<String> deleteOrder(@PathVariable("id") Long id, @RequestParam String email);
    
    
    
    @GetMapping("/feedback/order/{orderId}/customer")
    FeedbackDTO getFeedbackForOrder(@PathVariable("orderId") Long orderId,
                                    @RequestHeader("customerEmail") String customerEmail);
    
    
    @PostMapping("/rating/order/{orderId}")
    ResponseEntity<String> rateWasher(@PathVariable("orderId") Long orderId,
                                      @RequestBody RatingRequestDTO dto,
                                      @RequestHeader("customerEmail") String customerEmail);

    @GetMapping("/rating/all")
    List<WasherRatingDTO> getAllWasherRatings();

    @GetMapping("/rating/leaderboard")
    List<LeaderboardDTO> getLeaderboard();
    
}
