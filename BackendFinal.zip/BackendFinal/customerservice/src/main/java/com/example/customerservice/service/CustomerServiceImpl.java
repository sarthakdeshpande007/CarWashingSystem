package com.example.customerservice.service;

import com.example.customerservice.dto.CustomerDTO;
import com.example.customerservice.dto.LoginRequest;
import com.example.customerservice.dto.PaymentRequest;
import com.example.customerservice.entity.Customer;
import com.example.customerservice.feign.PaymentClient;
import com.example.customerservice.repository.CustomerRepository;
import com.example.customerservice.security.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.springframework.transaction.annotation.Transactional;
@Service
public class CustomerServiceImpl implements CustomerService {

    @Autowired private CustomerRepository repository;
    @Autowired private BCryptPasswordEncoder encoder;
    @Autowired private JwtUtil jwtUtil;

    private final Pattern emailPattern = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$");
    private final Pattern phonePattern = Pattern.compile("^\\d{10}$");
    private final Pattern passwordPattern = Pattern.compile("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=]).{8,}$");

    @Override
    public String register(CustomerDTO dto) {
        if (!emailPattern.matcher(dto.getEmail()).matches()) {
            return "Invalid email format.";
        }
        if (!phonePattern.matcher(dto.getPhoneNo()).matches()) {
            return "Phone number must be 10 digits.";
        }
        if (!passwordPattern.matcher(dto.getPassword()).matches()) {
            return "Password must be at least 8 characters, include uppercase, lowercase, digit, and special character.";
        }
        if (repository.findByUsername(dto.getUsername()).isPresent()) {
            return "Username already exists!";
        }
        if (repository.findByEmail(dto.getEmail()).isPresent()) {
            return "Email already in use!";
        }

        Customer customer = new Customer();
        customer.setEmail(dto.getEmail());
        customer.setUsername(dto.getUsername());
        customer.setPhoneNo(dto.getPhoneNo());
        customer.setPassword(encoder.encode(dto.getPassword()));

        repository.save(customer);
        return "Registered Successfully!";
    }

    @Override
    public String login(LoginRequest login) {
        Optional<Customer> customerOpt = repository.findByEmail(login.getEmail());
        if (customerOpt.isEmpty()) return "Invalid credentials!";

        Customer customer = customerOpt.get();
        if (encoder.matches(login.getPassword(), customer.getPassword())) {
            List<String> roles = List.of("ROLE_CUSTOMER");  // ✅ Assign CUSTOMER role
            return jwtUtil.generateToken(customer.getEmail(), roles);
        } else {
            return "Invalid credentials!";
        }
    }


    @Override
    public String logout(String token) {
        return "Logged out successfully. Please discard the token on client side.";
    }
  

    @Override
    public String updateProfile(String email, CustomerDTO dto) {
        Optional<Customer> customerOpt = repository.findByEmail(email);
        if (customerOpt.isEmpty()) return "User not found!";

        // Prevent changing email
        if (!dto.getEmail().equalsIgnoreCase(email)) {
            return "Email cannot be updated!";
        }

        Customer customer = customerOpt.get();

        if (!phonePattern.matcher(dto.getPhoneNo()).matches()) {
            return "Phone number must be 10 digits.";
        }
        if (!passwordPattern.matcher(dto.getPassword()).matches()) {
            return "Password must be at least 8 characters, include uppercase, lowercase, digit, and special character.";
        }

        // Check for duplicate username if it's being changed
        if (!dto.getUsername().equalsIgnoreCase(customer.getUsername()) &&
            repository.findByUsername(dto.getUsername()).isPresent()) {
            return "Username already exists!";
        }

        customer.setUsername(dto.getUsername());
        customer.setPhoneNo(dto.getPhoneNo());
        customer.setPassword(encoder.encode(dto.getPassword()));

        repository.save(customer);
        return "Profile updated!";
    }

    
    @Override
    @Transactional
    public String deleteAccount(String email) {
        Optional<Customer> customerOpt = repository.findByEmail(email);
        if (customerOpt.isEmpty()) return "User not found!";

        repository.deleteByEmail(email);
        return "Account and all related data deleted successfully.";
    }
    
    
    @Autowired
    private PaymentClient paymentClient;

    public String payForWash(String email, double amount) {
        PaymentRequest request = new PaymentRequest();
        request.setEmail(email);
        request.setAmount(amount);

        return paymentClient.initiatePayment(request);
    }
    
    @Override
    public CustomerDTO getCustomerByEmail(String email) {
        Customer customer = repository.findByEmail(email)
            .orElseThrow(() -> new RuntimeException("Customer not found with email: " + email));

        CustomerDTO dto = new CustomerDTO();
        dto.setEmail(customer.getEmail());
        dto.setUsername(customer.getUsername()); // username stores full name
        dto.setPhoneNo(customer.getPhoneNo());
        return dto;
    }
    
    
    
    
   

    
    
   



}