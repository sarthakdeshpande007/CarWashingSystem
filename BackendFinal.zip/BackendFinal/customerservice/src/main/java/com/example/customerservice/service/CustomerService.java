package com.example.customerservice.service;

import java.util.List;

import com.example.customerservice.dto.CustomerDTO;
import com.example.customerservice.dto.LoginRequest;

public interface CustomerService {
    String register(CustomerDTO dto);
    String login(LoginRequest login);
    String logout(String token);
    String updateProfile(String email, CustomerDTO updatedData);
    String deleteAccount(String email);
    
    String payForWash(String email, double amount);
    public CustomerDTO getCustomerByEmail(String email);
    
    



}