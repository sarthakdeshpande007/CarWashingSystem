package com.example.customerservice.controller;
import com.example.customerservice.dto.CustomerDTO;
import com.example.customerservice.dto.RatingRequestDTO;
import com.example.customerservice.dto.WasherRatingDTO;
import com.example.customerservice.dto.LeaderboardDTO;


import com.example.customerservice.dto.WashPackageDTO;
import com.example.customerservice.feign.CartServiceClient;
import com.example.customerservice.dto.CustomerOrderInputDTO;
import com.example.customerservice.dto.FeedbackDTO;
import com.example.customerservice.dto.OrderRequestDTO;
import com.example.customerservice.feign.OrderClient;
import com.example.customerservice.dto.LoginRequest;
import com.example.customerservice.security.JwtUtil;
import com.example.customerservice.service.CustomerService;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;
@RestController
@RequestMapping("/api/customers")
@SecurityRequirement(name = "bearerAuth")
public class CustomerController {

    @Autowired private CustomerService service;
    @Autowired private JwtUtil jwtUtil;

    @PostMapping("/register")
    public String register(@RequestBody CustomerDTO dto) {
        return service.register(dto);
    }

    @PostMapping("/login")
    public String login(@RequestBody LoginRequest login) {
        return service.login(login);
    }

    @PostMapping("/logout")
    public String logout(@RequestHeader("Authorization") String token) {
        return service.logout(token);
    }

//    @PutMapping("/update")
//    public String updateProfile(@AuthenticationPrincipal String email, @RequestBody CustomerDTO dto) {
//        return service.updateProfile(email, dto);
//    }
    
    @PutMapping("/update")
    public String updateProfile(@AuthenticationPrincipal UserDetails user, @RequestBody CustomerDTO dto) {
        return service.updateProfile(user.getUsername(), dto);
    }

    
    @DeleteMapping("/delete")
    public String deleteAccount(@AuthenticationPrincipal String email) {
        return service.deleteAccount(email);
    }

    
    @Autowired
    private CustomerService customerService;

    
    @GetMapping("/profile")
    public CustomerDTO getProfile() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        if (authentication == null || !authentication.isAuthenticated()) {
            throw new RuntimeException("Unauthorized access");
        }

        String email = authentication.getName(); // ✅ no cast to User
        return customerService.getCustomerByEmail(email);
    }
    
    @PostMapping("/pay")
    public String pay(@AuthenticationPrincipal UserDetails user, @RequestParam double amount) {
        return service.payForWash(user.getUsername(), amount);
    }

    @Autowired private OrderClient orderClient;
    
    
    @PostMapping("/place-order")
    public ResponseEntity<String> placeOrder(@AuthenticationPrincipal UserDetails user
,
                                             @RequestBody CustomerOrderInputDTO input) {

        CustomerDTO customer = service.getCustomerByEmail(user.getUsername());

        // Map input DTO to full OrderRequestDTO
        OrderRequestDTO dto = new OrderRequestDTO();

        dto.setCustomerEmail(customer.getEmail());
        dto.setCustomerName(customer.getUsername());
        dto.setPhoneNo(customer.getPhoneNo());

        dto.setPackageType(input.getPackageType());
        dto.setAddOns(input.getAddOns());
        dto.setAddress(input.getAddress());
        dto.setDateTime(input.getDateTime());

        dto.setWasherName(input.getWasherName());
        dto.setWasherEmail(input.getWasherEmail());
        dto.setWasherId(input.getWasherId());

        dto.setStatus("pending");

        return orderClient.placeOrder(dto);
    }

    
    
    @GetMapping("/orders")
    public List<Object> getOrdersByStatus(@AuthenticationPrincipal UserDetails user,
                                          @RequestParam String status) {
        return orderClient.getOrdersByStatus(user.getUsername(), status);
    }

    @PutMapping("/orders/{id}")
    public ResponseEntity<String> updateOrder(@AuthenticationPrincipal UserDetails user,
                                              @PathVariable Long id,
                                              @RequestBody OrderRequestDTO dto) {
        return orderClient.updateOrder(id, user.getUsername(), dto);
    }

    @DeleteMapping("/orders/{id}")
    public ResponseEntity<String> deleteOrder(@AuthenticationPrincipal UserDetails user,
                                              @PathVariable Long id) {
        return orderClient.deleteOrder(id, user.getUsername());
    }
    
    
   
    @Autowired
    private CartServiceClient cartClient;

    @GetMapping("/view-wash-packages")
    public List<WashPackageDTO> viewAllPackages() {
        return cartClient.getAllPackages();
    }
    
    
    
    @GetMapping("/orders/{orderId}/feedback")
    public ResponseEntity<FeedbackDTO> getFeedbackForOrder(@AuthenticationPrincipal UserDetails user,
                                                           @PathVariable Long orderId) {
        String customerEmail = user.getUsername(); // from JWT
        FeedbackDTO feedback = orderClient.getFeedbackForOrder(orderId, customerEmail);
        return ResponseEntity.ok(feedback);
    }
    
    
    
    /**  Submit a rating for a washer on a specific order (1 ‑ 10) */
    @PostMapping("/orders/{orderId}/rate")
    public ResponseEntity<String> rateWasher(@AuthenticationPrincipal UserDetails user,
                                             @PathVariable Long orderId,
                                             @RequestBody RatingRequestDTO dto) {
        return orderClient.rateWasher(orderId, dto, user.getUsername());
    }

    /**  See every washer’s cumulative rating (avg + count) */
    @GetMapping("/washers/ratings")
    public List<WasherRatingDTO> viewAllWasherRatings() {
        return orderClient.getAllWasherRatings();
    }

    /**  Leaderboard: highest‑rated washer comes first (rank 1) */
    @GetMapping("/washers/leaderboard")
    public List<LeaderboardDTO> leaderboard() {
        return orderClient.getLeaderboard();
    }


  

}
