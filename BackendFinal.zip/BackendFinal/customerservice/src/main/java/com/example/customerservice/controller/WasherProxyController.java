package com.example.customerservice.controller;

import com.example.customerservice.feign.WasherClient;
import com.example.customerservice.dto.WasherDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import org.springframework.web.bind.annotation.RestController;
@RestController
@SecurityRequirement(name = "bearerAuth") 

@RequestMapping("/api/customers/washers")
public class WasherProxyController {

    @Autowired
    private WasherClient washerClient;

    @GetMapping("/all")
    public ResponseEntity<List<WasherDTO>> getAllWashersFromWasherService() {
        List<WasherDTO> washers = washerClient.getAllWashers();
        return ResponseEntity.ok(washers);
    }
}
