package com.example.customerservice.dto;


import java.time.LocalDateTime;

public class CustomerOrderInputDTO {
    private String packageType;
    private String addOns;
    private String address;
    private LocalDateTime dateTime;

    private String washerName;
    private String washerEmail;
    private Long washerId;

    // Getters and Setters
    public String getPackageType() {
        return packageType;
    }
    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getAddOns() {
        return addOns;
    }
    public void setAddOns(String addOns) {
        this.addOns = addOns;
    }

    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }
    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getWasherName() {
        return washerName;
    }
    public void setWasherName(String washerName) {
        this.washerName = washerName;
    }

    public String getWasherEmail() {
        return washerEmail;
    }
    public void setWasherEmail(String washerEmail) {
        this.washerEmail = washerEmail;
    }

    public Long getWasherId() {
        return washerId;
    }
    public void setWasherId(Long washerId) {
        this.washerId = washerId;
    }
}
