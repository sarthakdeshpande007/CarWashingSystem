package com.example.customerservice.feign;


import com.example.customerservice.dto.WasherDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "washerservice", url = "http://localhost:8083")
public interface WasherClient {

    @GetMapping("/api/washers/public/all")
    List<WasherDTO> getAllWashers();
}
