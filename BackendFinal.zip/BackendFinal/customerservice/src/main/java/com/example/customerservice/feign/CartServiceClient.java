package com.example.customerservice.feign;

import com.example.customerservice.dto.WashPackageDTO;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.List;

@FeignClient(name = "cartservice", url = "http://localhost:8089")  // Adjust port if needed
public interface CartServiceClient {

    @GetMapping("/wash-packages")
    List<WashPackageDTO> getAllPackages();
}
