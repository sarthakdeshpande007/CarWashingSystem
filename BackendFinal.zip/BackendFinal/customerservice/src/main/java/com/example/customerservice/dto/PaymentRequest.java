package com.example.customerservice.dto;

//package: com.example.customerservice.dto

public class PaymentRequest {
 private String email;
 public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public double getAmount() {
	return amount;
}
public void setAmount(double amount) {
	this.amount = amount;
}
private double amount;

 // Getters and Setters
}
