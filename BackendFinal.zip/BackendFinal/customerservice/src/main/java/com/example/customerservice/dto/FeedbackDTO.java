package com.example.customerservice.dto;

public class FeedbackDTO {
    private Long orderId;
    private String washerEmail;
    private double waterSaved;
    private String notes;

    public FeedbackDTO() {}

    public FeedbackDTO(Long orderId, String washerEmail, double waterSaved, String notes) {
        this.orderId = orderId;
        this.washerEmail = washerEmail;
        this.waterSaved = waterSaved;
        this.notes = notes;
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getWasherEmail() {
        return washerEmail;
    }

    public void setWasherEmail(String washerEmail) {
        this.washerEmail = washerEmail;
    }

    public double getWaterSaved() {
        return waterSaved;
    }

    public void setWaterSaved(double waterSaved) {
        this.waterSaved = waterSaved;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
}
