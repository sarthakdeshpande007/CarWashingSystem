package com.example.customerservice.dto;


import java.time.LocalDateTime;

public class OrderRequestDTO {

    private String customerName;
    private String customerEmail;
    private String phoneNo;

    private String packageType;
    private String addOns;
    private String address;
    private LocalDateTime dateTime;

    private String status;      // Optional for customer; defaults to "pending"
    private String washerName;  // For admin/washer use
    private String washerEmail;
    private Long washerId;

    // Getters and Setters

    public String getCustomerName() {
        return customerName;
    }
    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerEmail() {
        return customerEmail;
    }
    public void setCustomerEmail(String customerEmail) {
        this.customerEmail = customerEmail;
    }

    public String getPhoneNo() {
        return phoneNo;
    }
    public void setPhoneNo(String phoneNo) {
        this.phoneNo = phoneNo;
    }

    public String getPackageType() {
        return packageType;
    }
    public void setPackageType(String packageType) {
        this.packageType = packageType;
    }

    public String getAddOns() {
        return addOns;
    }
    public void setAddOns(String addOns) {
        this.addOns = addOns;
    }

    public String getAddress() {
        return address;
    }
    public void setAddress(String address) {
        this.address = address;
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }
    public void setDateTime(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }

    public String getWasherName() {
        return washerName;
    }
    public void setWasherName(String washerName) {
        this.washerName = washerName;
    }

    public String getWasherEmail() {
        return washerEmail;
    }
    public void setWasherEmail(String washerEmail) {
        this.washerEmail = washerEmail;
    }

    public Long getWasherId() {
        return washerId;
    }
    public void setWasherId(Long washerId) {
        this.washerId = washerId;
    }
}
