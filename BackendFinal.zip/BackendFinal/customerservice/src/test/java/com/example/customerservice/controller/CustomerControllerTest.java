package com.example.customerservice.controller;

import com.example.customerservice.dto.CustomerDTO;
import com.example.customerservice.dto.LoginRequest;
import com.example.customerservice.security.JwtUtil;
import com.example.customerservice.service.CustomerService;

import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;

import org.springframework.test.web.servlet.MockMvc;
import com.fasterxml.jackson.databind.ObjectMapper;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CustomerController.class)
class CustomerControllerTest {

    @Autowired private MockMvc mockMvc;

    @MockBean private CustomerService customerService;
    @MockBean private JwtUtil jwtUtil;

    @Autowired private ObjectMapper objectMapper;

    @Test
    void testRegister_Success() throws Exception {
        CustomerDTO dto = new CustomerDTO();
        when(customerService.register(any(CustomerDTO.class))).thenReturn("Registered Successfully!");

        mockMvc.perform(post("/api/customers/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(content().string("Registered Successfully!"));
    }

    @Test
    void testLogin_Success() throws Exception {
        LoginRequest login = new LoginRequest("john@example.com", "Password@123");
        when(customerService.login(any(LoginRequest.class))).thenReturn("mock-jwt-token");

        mockMvc.perform(post("/api/customers/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(login)))
                .andExpect(status().isOk())
                .andExpect(content().string("mock-jwt-token"));
    }

    @Test
    @WithMockUser(username = "john@example.com", roles = {"CUSTOMER"})
    void testUpdateProfile() throws Exception {
        CustomerDTO dto = new CustomerDTO();
        when(customerService.updateProfile(Mockito.eq("john@example.com"), any(CustomerDTO.class)))
                .thenReturn("Profile updated!");

        mockMvc.perform(put("/api/customers/update")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(dto)))
                .andExpect(status().isOk())
                .andExpect(content().string("Profile updated!"));
    }

    @Test
    @WithMockUser(username = "john@example.com", roles = {"CUSTOMER"})
    void testDeleteAccount() throws Exception {
        when(customerService.deleteAccount("john@example.com")).thenReturn("Account and all related data deleted successfully.");

        mockMvc.perform(delete("/api/customers/delete"))
                .andExpect(status().isOk())
                .andExpect(content().string("Account and all related data deleted successfully."));
    }

    @Test
    @WithMockUser(username = "john@example.com", roles = {"CUSTOMER"})
    void testLogout() throws Exception {
        mockMvc.perform(post("/api/customers/logout")
                        .header("Authorization", "Bearer dummy-token"))
                .andExpect(status().isOk())
                .andExpect(content().string("Logged out successfully. Please discard the token on client side."));
    }
}
