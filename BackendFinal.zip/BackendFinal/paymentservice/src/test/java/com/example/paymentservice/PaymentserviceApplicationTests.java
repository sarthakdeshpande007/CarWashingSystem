package com.example.paymentservice;

import com.example.paymentservice.controller.PaymentController;
import com.example.paymentservice.dto.PaymentRequest;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class PaymentserviceApplicationTests {

    @Test
    void contextLoads() {
        // Check that Spring context loads
        assertTrue(true);
    }

    @Test
    void testPaymentRequestDTO() {
        // Simple DTO test
        PaymentRequest request = new PaymentRequest();
        request.setEmail("test@example.com");
        request.setAmount(200.0);

        assertEquals("test@example.com", request.getEmail());
        assertEquals(200.0, request.getAmount());
    }

    @Test
    void testPaymentControllerMethodReturnsError() {
        PaymentController controller = new PaymentController();
        // Razorpay keys are empty, it will fail and return error string
        PaymentRequest request = new PaymentRequest();
        request.setEmail("test@example.com");
        request.setAmount(100.0);

        String response = controller.initiatePayment(request);

        System.out.println("Response = " + response);

        assertTrue(response.contains("Error initiating payment"));
    }
}
