package com.example.paymentservice.controller;

import com.example.paymentservice.dto.PaymentRequest;
import com.razorpay.Order;
import com.razorpay.RazorpayClient;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Value("${razorpay.key_id}")
    private String razorpayKeyId;

    @Value("${razorpay.key_secret}")
    private String razorpaySecret;

    @PostMapping("/initiate")
    public String initiatePayment(@RequestBody PaymentRequest request) {
        try {
            RazorpayClient client = new RazorpayClient(razorpayKeyId, razorpaySecret);

            JSONObject options = new JSONObject();
            options.put("amount", (int)(request.getAmount() * 100)); // Convert to paise
            options.put("currency", "INR");
            options.put("receipt", "txn_" + System.currentTimeMillis());
            options.put("payment_capture", 1);

            Order order = client.orders.create(options);
            return order.toString(); // contains order_id, amount, etc.

        } catch (Exception e) {
            return "Error initiating payment: " + e.getMessage();
        }
    }
}
