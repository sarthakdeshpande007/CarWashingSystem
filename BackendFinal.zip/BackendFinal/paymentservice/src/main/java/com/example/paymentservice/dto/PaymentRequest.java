package com.example.paymentservice.dto;


public class PaymentRequest {
    public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	private String email;
    private double amount;

    // Getters and Setters
}
