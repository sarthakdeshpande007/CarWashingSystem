package com.carwash.orderservice.repository;

import com.carwash.orderservice.dto.WasherRatingDTO;
import com.carwash.orderservice.entity.Rating;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface RatingRepository extends JpaRepository<Rating, Long> {

    boolean existsByOrderId(Long orderId);

    @Query("""
        SELECT new com.carwash.orderservice.dto.WasherRatingDTO(
            r.washerEmail,
            AVG(r.rating),
            COUNT(r)
        )
        FROM Rating r
        GROUP BY r.washerEmail
        ORDER BY AVG(r.rating) DESC
    """)
    List<WasherRatingDTO> findWasherRatings();
    
    List<Rating> findByWasherEmail(String washerEmail);  // ✅ ADD THIS

}
