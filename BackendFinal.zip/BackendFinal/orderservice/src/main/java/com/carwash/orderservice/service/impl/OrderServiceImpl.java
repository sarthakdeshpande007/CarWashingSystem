package com.carwash.orderservice.service.impl;

import com.carwash.orderservice.entity.Order;
import com.carwash.orderservice.repository.OrderRepository;
import com.carwash.orderservice.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;
import java.util.Optional;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository repository;


    
    public Order createOrder(Order order) {
        try {
            System.out.println("📦 Incoming Order Data:");
            System.out.println("Customer Name: " + order.getCustomerName());
            System.out.println("Customer Email: " + order.getCustomerEmail());
            System.out.println("Phone No: " + order.getPhoneNo());
            System.out.println("Package Type: " + order.getPackageType());
            System.out.println("Add-Ons: " + order.getAddOns());
            System.out.println("Address: " + order.getAddress());
            System.out.println("DateTime: " + order.getDateTime());
            System.out.println("Washer Name: " + order.getWasherName());
            System.out.println("Washer Email: " + order.getWasherEmail());
            System.out.println("Washer ID: " + order.getWasherId());

            order.setStatus("pending"); // default status
            return repository.save(order);
        } catch (Exception e) {
            System.out.println("❌ Failed to save order due to:");
            e.printStackTrace(); // Full stack trace
            throw new RuntimeException("Failed to create order: " + e.getMessage());
        }
    }
    
    
    



    @Override
    public List<Order> getOrdersByStatus(String email, String category) {
        switch (category.toLowerCase()) {
            case "unassigned":
                return repository.findByCustomerEmailAndStatus(email, "pending");

            case "current":
                return repository.findByCustomerEmailAndStatusIn(email, List.of("started", "in-progress"));

            case "past":
                return repository.findByCustomerEmailAndStatus(email, "completed");

            default:
                throw new IllegalArgumentException("Invalid status category. Use: unassigned, current, past");
        }
    }

    public Order updateOrder(Long id, Order updatedOrder, String email) {
        Order existing = repository.findById(id).orElseThrow();
        if (!existing.getCustomerEmail().equals(email)) {
            throw new RuntimeException("Unauthorized: You can only update your own orders");
        }

        existing.setPackageType(updatedOrder.getPackageType());
        existing.setAddOns(updatedOrder.getAddOns());
        existing.setAddress(updatedOrder.getAddress());
        existing.setDateTime(updatedOrder.getDateTime());
        existing.setPhoneNo(updatedOrder.getPhoneNo());

        return repository.save(existing);
    }
    
   


   public void deleteOrder(Long id, String email) {
        Order existing = repository.findById(id).orElseThrow();
        if (!existing.getCustomerEmail().equals(email)) {
            throw new RuntimeException("Unauthorized: You can only delete your own orders");
        }
        repository.delete(existing);
    }
    
    
  

    
   
   
   @Override
   public List<Order> getOrdersForWasherByStatus(String washerEmail, String category) {
       List<String> statuses;

       switch (category.toLowerCase()) {
           case "current":
               statuses = List.of("started", "in-progress");
               break;
           case "past":
               statuses = List.of("completed");
               break;
           case "unassigned": // 👈 new case for pending orders
               statuses = List.of("pending");
               break;
           default:
               throw new IllegalArgumentException("Invalid category. Use: current, past, or unassigned");
       }

       return repository.findByWasherEmailAndStatusIn(washerEmail, statuses);
   }


    @Override
    public Order updateOrderStatusByWasher(Long orderId, String washerEmail, String newStatus) {
        Order order = repository.findByOrderIdAndWasherEmail(orderId, washerEmail)
                .orElseThrow(() -> new RuntimeException("Unauthorized: Order not assigned to this washer"));

        order.setStatus(newStatus);
        return repository.save(order);
    }
    
    
   
   
   


}
