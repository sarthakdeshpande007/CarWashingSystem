package com.carwash.orderservice.dto;

public class LeaderboardDTO {
    private int rank;
    private String washerEmail;
    private double averageRating;
    private long totalRatings;

    public LeaderboardDTO(int rank, WasherRatingDTO dto) {
        this.rank = rank;
        this.washerEmail = dto.getWasherEmail();
        this.averageRating = dto.getAverageRating();
        this.totalRatings = dto.getTotalRatings();
    }

    public int getRank() {
        return rank;
    }

    public String getWasherEmail() {
        return washerEmail;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public long getTotalRatings() {
        return totalRatings;
    }
}
