package com.carwash.orderservice.controller;

import com.carwash.orderservice.dto.*;
import com.carwash.orderservice.entity.Order;
import com.carwash.orderservice.entity.Rating;
import com.carwash.orderservice.repository.OrderRepository;
import com.carwash.orderservice.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@RestController
@RequestMapping("/orders/rating")
public class CustomerRatingController {

    @Autowired
    private RatingRepository ratingRepo;

    @Autowired
    private OrderRepository orderRepo;

    @PostMapping("/order/{orderId}")
    public ResponseEntity<String> rateWasher(@PathVariable Long orderId,
                                             @RequestBody RatingRequestDTO dto,
                                             @RequestHeader("customerEmail") String customerEmail) {

        if (dto.getRating() < 1 || dto.getRating() > 10)
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Rating must be between 1 and 10");

        Order order = orderRepo.findByOrderIdAndCustomerEmail(orderId, customerEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN,
                        "Order not found for this customer"));

        if (ratingRepo.existsByOrderId(orderId))
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Rating already submitted for this order");

        Rating saved = ratingRepo.save(
                new Rating(orderId, order.getWasherEmail(), customerEmail, dto.getRating(), dto.getReview()));

        return ResponseEntity.ok("✅ Rating saved with ID: " + saved.getId());
    }

    @GetMapping("/all")
    public ResponseEntity<List<WasherRatingDTO>> getAllWasherRatings() {
        return ResponseEntity.ok(ratingRepo.findWasherRatings());
    }

    @GetMapping("/leaderboard")
    public ResponseEntity<List<LeaderboardDTO>> getLeaderboard() {
        List<WasherRatingDTO> list = ratingRepo.findWasherRatings();
        List<LeaderboardDTO> board = IntStream.range(0, list.size())
                .mapToObj(i -> new LeaderboardDTO(i + 1, list.get(i)))
                .toList();

        return ResponseEntity.ok(board);
    }
    
    @GetMapping("/my-ratings")
    public ResponseEntity<List<WasherIndividualRatingDTO>> getRatingsForWasher(@RequestHeader("washerEmail") String washerEmail) {
        List<Rating> all = ratingRepo.findByWasherEmail(washerEmail);
        List<WasherIndividualRatingDTO> result = all.stream()
            .map(r -> new WasherIndividualRatingDTO(r.getCustomerEmail(), r.getRating(), r.getReview()))
            .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }



}
