package com.carwash.orderservice.service;

import com.carwash.orderservice.entity.Order;
import java.util.List;
import java.util.Optional;

public interface OrderService {
    Order createOrder(Order order);
    List<Order> getOrdersByStatus(String email, String status);
    Order updateOrder(Long id, Order updatedOrder, String email);
    void deleteOrder(Long id, String email);
    
    
    List<Order> getOrdersForWasherByStatus(String washerEmail, String category);
    Order updateOrderStatusByWasher(Long orderId, String washerEmail, String newStatus);

    
    
  

}
