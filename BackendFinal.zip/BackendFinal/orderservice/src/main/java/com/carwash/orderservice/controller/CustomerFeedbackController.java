package com.carwash.orderservice.controller;

import com.carwash.orderservice.entity.Feedback;
import com.carwash.orderservice.repository.FeedbackRepository;
import com.carwash.orderservice.repository.OrderRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

@RestController
@RequestMapping("/orders/feedback")
public class CustomerFeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private OrderRepository orderRepository;

    @GetMapping("/order/{orderId}/customer")
    public ResponseEntity<Feedback> getFeedbackForCustomer(@PathVariable Long orderId,
                                                           @RequestHeader("customerEmail") String customerEmail) {
        orderRepository.findByOrderIdAndCustomerEmail(orderId, customerEmail)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN,
                        "❌ You are not allowed to view feedback for this order"));

        Feedback feedback = feedbackRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "⚠️ No feedback found for Order ID: " + orderId));

        return ResponseEntity.ok(feedback);
    }
}
