package com.carwash.orderservice.repository;

import com.carwash.orderservice.entity.Feedback;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FeedbackRepository extends JpaRepository<Feedback, Long> {
	
	Optional<Feedback> findByOrderId(Long orderId);
    Optional<Feedback> findByOrderIdAndWasherEmail(Long orderId, String washerEmail);
    boolean existsByOrderId(Long orderId);
    

}
