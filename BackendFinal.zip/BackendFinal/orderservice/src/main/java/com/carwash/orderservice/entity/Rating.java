package com.carwash.orderservice.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
public class Rating {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getWasherEmail() {
		return washerEmail;
	}

	public void setWasherEmail(String washerEmail) {
		this.washerEmail = washerEmail;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getReview() {
		return review;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	private Long orderId;
    private String washerEmail;
    private String customerEmail;

    private int rating;
    private String review;

    private LocalDateTime createdAt = LocalDateTime.now();

    public Rating() {}

    public Rating(Long orderId, String washerEmail, String customerEmail, int rating, String review) {
        this.orderId = orderId;
        this.washerEmail = washerEmail;
        this.customerEmail = customerEmail;
        this.rating = rating;
        this.review = review;
    }

    // Getters and Setters
    // ...
}
