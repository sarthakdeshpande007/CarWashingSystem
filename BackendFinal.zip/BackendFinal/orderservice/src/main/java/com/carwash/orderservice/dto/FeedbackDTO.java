package com.carwash.orderservice.dto;

public class FeedbackDTO {
    private Long id;       // <-- added

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public double getWaterSaved() {
		return waterSaved;
	}

	public void setWaterSaved(double waterSaved) {
		this.waterSaved = waterSaved;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	private Long orderId;
    private double waterSaved;
    private String notes;

    public FeedbackDTO() {}

    public FeedbackDTO(Long id, Long orderId, double waterSaved, String notes) {
        this.id = id;
        this.orderId = orderId;
        this.waterSaved = waterSaved;
        this.notes = notes;
    }
    // Getters and Setters
}
