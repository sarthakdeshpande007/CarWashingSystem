package com.carwash.orderservice.dto;

public class WasherRatingDTO {
    private String washerEmail;
    private double averageRating;
    private long totalRatings;

    public WasherRatingDTO(String washerEmail, double averageRating, long totalRatings) {
        this.washerEmail = washerEmail;
        this.averageRating = averageRating;
        this.totalRatings = totalRatings;
    }

    public String getWasherEmail() {
        return washerEmail;
    }

    public double getAverageRating() {
        return averageRating;
    }

    public long getTotalRatings() {
        return totalRatings;
    }
}
