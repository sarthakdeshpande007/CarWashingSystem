package com.carwash.orderservice.entity;

import jakarta.persistence.*;

@Entity
public class Feedback {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getWasherEmail() {
		return washerEmail;
	}

	public void setWasherEmail(String washerEmail) {
		this.washerEmail = washerEmail;
	}

	public double getWaterSaved() {
		return waterSaved;
	}

	public void setWaterSaved(double waterSaved) {
		this.waterSaved = waterSaved;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	private Long orderId;

    private String washerEmail;

    private double waterSaved;

    private String notes;

    // Constructors
    public Feedback() {}

    public Feedback(Long orderId, String washerEmail, double waterSaved, String notes) {
        this.orderId = orderId;
        this.washerEmail = washerEmail;
        this.waterSaved = waterSaved;
        this.notes = notes;
    }

    // Getters & Setters
    // (manual or use Lombok if allowed)
}
