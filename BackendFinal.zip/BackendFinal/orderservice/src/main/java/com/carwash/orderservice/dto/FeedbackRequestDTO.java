package com.carwash.orderservice.dto;

public class FeedbackRequestDTO {
    public double getWaterSaved() {
		return waterSaved;
	}
	public void setWaterSaved(double waterSaved) {
		this.waterSaved = waterSaved;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	private double waterSaved;
    private String notes;

    public FeedbackRequestDTO() {}
    public FeedbackRequestDTO(double waterSaved, String notes) {
        this.waterSaved = waterSaved;
        this.notes = notes;
    }

    // Getters and Setters
}
