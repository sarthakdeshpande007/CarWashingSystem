package com.carwash.orderservice.controller;

import com.carwash.orderservice.entity.Order;
import com.carwash.orderservice.service.OrderService;

import org.apache.hc.core5.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/orders")
public class OrderController {

    @Autowired
    private OrderService service;

    @PostMapping
    public ResponseEntity<Order> placeOrder(@RequestBody Order order) {
        return ResponseEntity.ok(service.createOrder(order));
    }

    @GetMapping("/status")
    public ResponseEntity<List<Order>> getOrdersByStatus(
            @RequestParam String email,
            @RequestParam String status) {
        return ResponseEntity.ok(service.getOrdersByStatus(email, status));
    }

    @PutMapping("/{id}")
    public ResponseEntity<Order> updateOrder(
            @PathVariable Long id,
            @RequestParam String email,
            @RequestBody Order updatedOrder) {
        return ResponseEntity.ok(service.updateOrder(id, updatedOrder, email));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteOrder(
            @PathVariable Long id,
            @RequestParam String email) {
        service.deleteOrder(id, email);
        return ResponseEntity.ok("Order deleted successfully");
    }
    
    
    
    @GetMapping("/washer")
    public ResponseEntity<List<Order>> getOrdersForWasher(
            @RequestParam String washerEmail,
            @RequestParam String status) {
        return ResponseEntity.ok(service.getOrdersForWasherByStatus(washerEmail, status));
    }

    @PutMapping("/washer/{orderId}/status")
    public ResponseEntity<Order> updateStatusByWasher(
            @PathVariable Long orderId,
            @RequestParam String washerEmail,
            @RequestParam String newStatus) {
        return ResponseEntity.ok(service.updateOrderStatusByWasher(orderId, washerEmail, newStatus));
    }
    
    
    
    





}
