package com.carwash.orderservice.controller;

import com.carwash.orderservice.dto.FeedbackDTO;
import com.carwash.orderservice.dto.FeedbackRequestDTO;
import com.carwash.orderservice.dto.LeaderboardDTO;
import com.carwash.orderservice.dto.WasherIndividualRatingDTO;
import com.carwash.orderservice.dto.WasherRatingDTO;
import com.carwash.orderservice.entity.Feedback;
import com.carwash.orderservice.entity.Order;
import com.carwash.orderservice.entity.Rating;
import com.carwash.orderservice.repository.FeedbackRepository;
import com.carwash.orderservice.repository.OrderRepository;
import com.carwash.orderservice.repository.RatingRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@RestController
@RequestMapping("/feedback")
public class FeedbackController {

    @Autowired
    private FeedbackRepository feedbackRepository;

    @Autowired
    private OrderRepository orderRepository;
    
    
    
    //submit feedback
    @PostMapping("/submit/{orderId}")
    public ResponseEntity<String> submitFeedback(@PathVariable Long orderId,
                                                 @RequestBody FeedbackRequestDTO dto,
                                                 @RequestHeader("washerEmail") String washerEmail) {
        Order order = orderRepository.findByOrderIdAndWasherEmail(orderId, washerEmail)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.FORBIDDEN,
                "❌ Unauthorized: Order not assigned to washer"));

        if (feedbackRepository.existsByOrderId(orderId)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "⚠️ Feedback already exists for this order");
        }

        Feedback feedback = new Feedback(orderId, washerEmail, dto.getWaterSaved(), dto.getNotes());
        Feedback saved = feedbackRepository.save(feedback);

        return ResponseEntity.ok("✅ Feedback submitted for Order ID: " + orderId +
                " with Feedback ID: " + saved.getId());
    }
    @Autowired
    private RatingRepository ratingRepo;
    
    @GetMapping("/leaderboard")
    public ResponseEntity<List<LeaderboardDTO>> getLeaderboard() {
        List<WasherRatingDTO> list = ratingRepo.findWasherRatings();
        List<LeaderboardDTO> board = IntStream.range(0, list.size())
                .mapToObj(i -> new LeaderboardDTO(i + 1, list.get(i)))
                .toList();

        return ResponseEntity.ok(board);
    }
    
 // Ratings given to this washer
    @GetMapping("/rating/my-ratings")
    public ResponseEntity<List<WasherIndividualRatingDTO>> getRatingsForWasher(@RequestHeader("washerEmail") String washerEmail) {
        List<Rating> all = ratingRepo.findByWasherEmail(washerEmail);
        List<WasherIndividualRatingDTO> result = all.stream()
            .map(r -> new WasherIndividualRatingDTO(r.getCustomerEmail(), r.getRating(), r.getReview()))
            .collect(Collectors.toList());
        return ResponseEntity.ok(result);
    }

/*
    //edit feedback based in feedback id
    @PutMapping("/{id}/edit")
    public ResponseEntity<String> editFeedback(@PathVariable Long id,
                                               @RequestBody FeedbackRequestDTO dto,
                                               @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "⚠️ Feedback not found"));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "❌ You are not authorized to edit this feedback");
        }

        feedback.setWaterSaved(dto.getWaterSaved());
        feedback.setNotes(dto.getNotes());

        feedbackRepository.save(feedback);

        return ResponseEntity.ok("✏️ Feedback updated for Order ID: " + feedback.getOrderId());
    }


    // ✅ 3. Delete Feedback based on feedback id
    @DeleteMapping("/{id}")
    public ResponseEntity<String> deleteFeedback(@PathVariable Long id,
                                                 @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Feedback not found"));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "❌ You can only delete your own feedback");
        }

        feedbackRepository.delete(feedback);
        return ResponseEntity.ok("🗑️ Feedback deleted for Order ID: " + feedback.getOrderId());
    }*/
    
    @PutMapping("/{id}/edit")
    public ResponseEntity<FeedbackDTO> editFeedback(@PathVariable Long id,
                                                   @RequestBody FeedbackRequestDTO dto,
                                                   @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "⚠️ Feedback not found"));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "❌ You are not authorized to edit this feedback");
        }

        feedback.setWaterSaved(dto.getWaterSaved());
        feedback.setNotes(dto.getNotes());

        Feedback updated = feedbackRepository.save(feedback);

        FeedbackDTO responseDTO = new FeedbackDTO(
                updated.getId(),
                updated.getOrderId(),
                updated.getWaterSaved(),
                updated.getNotes()
        );

        return ResponseEntity.ok(responseDTO);
    }

    
    @DeleteMapping("/{id}")
    public ResponseEntity<Long> deleteFeedback(@PathVariable Long id,
                                               @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Feedback not found"));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "❌ You can only delete your own feedback");
        }

        feedbackRepository.delete(feedback);
        return ResponseEntity.ok(feedback.getId()); // return deleted feedback ID
    }


    //get feedback based on feedback id
    @GetMapping("/{id}")
    public ResponseEntity<Feedback> getFeedbackById(@PathVariable Long id,
                                                    @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "⚠️ Feedback not found"));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "❌ Unauthorized: You can only view your own feedback");
        }

        return ResponseEntity.ok(feedback);
    }
//get all feedback
  /*  @GetMapping("/all")
    public ResponseEntity<List<Feedback>> getAllFeedbacksByWasher(@RequestHeader("washerEmail") String washerEmail) {
        List<Feedback> feedbacks = feedbackRepository.findAll()
                .stream()
                .filter(fb -> fb.getWasherEmail().equals(washerEmail))
                .toList();

        return ResponseEntity.ok(feedbacks);
    }
*/
    
    
    @GetMapping("/all")
    public ResponseEntity<List<FeedbackDTO>> getAllFeedbacksByWasher(@RequestHeader("washerEmail") String washerEmail) {
        List<FeedbackDTO> feedbacks = feedbackRepository.findAll()
                .stream()
                .filter(fb -> fb.getWasherEmail().equals(washerEmail))
                .map(fb -> new FeedbackDTO(
                        fb.getId(),
                        fb.getOrderId(),
                        fb.getWaterSaved(),
                        fb.getNotes()
                ))
                .toList();

        return ResponseEntity.ok(feedbacks);
    }


   
    //get feedback based on order id
    @GetMapping("/order/{orderId}")
    public ResponseEntity<Feedback> getFeedbackByOrderId(@PathVariable Long orderId,
                                                         @RequestHeader("washerEmail") String washerEmail) {
        Feedback feedback = feedbackRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "⚠️ No feedback found for Order ID: " + orderId));

        if (!feedback.getWasherEmail().equals(washerEmail)) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN,
                    "❌ Unauthorized: You are not allowed to view feedback for this order");
        }

        return ResponseEntity.ok(feedback);
    }

    
    
   


}
