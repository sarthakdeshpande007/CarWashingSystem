package com.carwash.orderservice.repository;

import com.carwash.orderservice.entity.Order;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerEmail(String email);
    List<Order> findByCustomerEmailAndStatus(String email, String status);
    List<Order> findByCustomerEmailAndStatusIn(String email, List<String> statuses);
    
    List<Order> findByWasherEmailAndStatusIn(String washerEmail, List<String> statuses);
    Optional<Order> findByOrderIdAndWasherEmail(Long orderId, String washerEmail);

    Optional<Order> findByOrderIdAndCustomerEmail(Long orderId, String customerEmail);

}
